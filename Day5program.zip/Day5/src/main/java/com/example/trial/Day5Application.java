package com.example.trial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day5Application {

	public static void main(String[] args) {
		SpringApplication.run(Day5Application.class, args);
	}

}
