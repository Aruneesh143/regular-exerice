package com.example.trial.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.trial.model.Mapmodel1;

public interface Map1Repo extends JpaRepository<Mapmodel1, Integer> {

}
