package com.example.trial.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.trial.model.Mapmodel2;

public interface Map2Repo extends JpaRepository<Mapmodel2, Integer> {

}
